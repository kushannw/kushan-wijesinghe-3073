/* fonts */
export const FontFamily = {
  interMedium: "Inter-Medium",
  plusJakartaSansMedium: "PlusJakartaSans-Medium",
  plusJakartaSansSemiBold: "PlusJakartaSans-SemiBold",
  plusJakartaSansBold: "PlusJakartaSans-Bold",
  plusJakartaSansExtraBold: "PlusJakartaSans-ExtraBold",
  jetBrainsMonoRegular: "JetBrainsMono-Regular",
  jetBrainsMonoBold: "JetBrainsMono-Bold",
};
/* font sizes */
export const FontSize = {
  size_3xs: 10,
  size_sm: 14,
  size_base: 16,
  size_xl: 20,
  size_5xl: 24,
  size_xs: 12,
  size_5xs: 8,
  size_13xl: 32,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  black: "#333",
  colorDarkslategray_100: "rgba(51, 51, 51, 0.1)",
  colorDarkslategray_200: "rgba(51, 51, 51, 0.2)",
  colorDarkgray: "#ababab",
  blue: "#1a52b5",
  colorGhostwhite: "#f3f6fb",
  colorGray_100: "#7e7e7e",
  colorGray_200: "#757575",
  colorGray_300: "rgba(255, 255, 255, 0.1)",
  colorSilver: "#c1c1c1",
};
/* Paddings */
export const Padding = {
  p_3xs: 10,
  p_4xl: 23,
  p_3xl: 22,
  p_xl: 20,
  p_xs: 12,
  p_12xs: 1,
  p_12xs_4: 0,
};
/* border radiuses */
export const Border = {
  br_5xs: 8,
  br_31xl: 50,
  br_xs: 12,
  br_7xs: 6,
  br_21xl: 40,
  br_37xl: 56,
};
