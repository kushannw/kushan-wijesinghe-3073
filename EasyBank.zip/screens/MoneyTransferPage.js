import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import TransferOptionsContainer from "../components/TransferOptionsContainer";
import FormContainer from "../components/FormContainer";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const MoneyTransferPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.moneyTransferPage}>
      <View style={[styles.moneyTransferPageChild, styles.moneyPosition]} />
      <LinearGradient
        style={[styles.moneyTransferPageItem, styles.moneyPosition]}
        locations={[0, 1]}
        colors={["#1a52b5", "#3875e1"]}
      />
      <Text style={[styles.text, styles.textTypo]}>285993209810</Text>
      <Text style={[styles.lkr5850015, styles.textTypo]}>LKR 58,500.15</Text>
      <Text style={styles.payFrom}>Pay From</Text>
      <Text style={[styles.availableBalance, styles.changeTypo]}>
        Available Balance
      </Text>
      <Text style={[styles.accountNumber, styles.changeTypo]}>
        Account Number
      </Text>
      <Text style={[styles.change, styles.changeTypo]}>Change</Text>
      <TransferOptionsContainer
        transferOptionsText="New Fund Transfer"
        frameViewPosition="absolute"
        frameViewTop={68}
        frameViewLeft={20}
      />
      <View style={styles.moneyTransferPageInner} />
      <View style={styles.rectangleView} />
      <Text style={[styles.receiverInformation, styles.registerTypo]}>
        Receiver Information
      </Text>
      <Image
        style={styles.arrowrightIcon}
        contentFit="cover"
        source={require("../assets/arrowright1.png")}
      />
      <View style={styles.combankNugegoda145Parent}>
        <Text style={[styles.combankNugegoda, styles.text1Typo]}>
          ComBank - Nugegoda 145
        </Text>
        <View style={[styles.frameChild, styles.frameLayout]} />
      </View>
      <View style={styles.parent}>
        <Text style={[styles.text1, styles.text1Typo]}>2568978451203</Text>
        <View style={[styles.frameItem, styles.frameLayout]} />
      </View>
      <FormContainer />
      <Pressable
        style={styles.mainBtn}
        onPress={() => navigation.navigate("TransferComfermation")}
      >
        <View style={[styles.registerWrapper, styles.frameParentFlexBox]}>
          <Text style={[styles.register, styles.registerTypo, register1Style]}>
            {register}
          </Text>
        </View>
      </Pressable>
      <View style={[styles.frameParent, styles.frameParentFlexBox]}>
        <Image
          style={styles.frameInner}
          contentFit="cover"
          source={require("../assets/frame-26860.png")}
        />
        <Text
          style={[styles.agreeTerms, styles.text1Typo]}
        >{`Agree Terms & Conditions`}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  moneyPosition: {
    width: 335,
    left: 20,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.plusJakartaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    top: 190,
    color: Color.colorWhite,
    position: "absolute",
  },
  changeTypo: {
    fontFamily: FontFamily.plusJakartaSansMedium,
    fontWeight: "500",
  },
  registerTypo: {
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_base,
  },
  text1Typo: {
    fontSize: FontSize.size_sm,
    textAlign: "left",
  },
  frameLayout: {
    height: 1,
    width: 334,
    borderTopWidth: 1,
    top: 30,
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
    position: "absolute",
  },
  frameParentFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  moneyTransferPageChild: {
    borderTopLeftRadius: Border.br_5xs,
    borderTopRightRadius: Border.br_5xs,
    backgroundColor: "rgba(26, 82, 181, 0.05)",
    height: 50,
    top: 282,
    width: 335,
  },
  moneyTransferPageItem: {
    top: 119,
    borderRadius: Border.br_xs,
    height: 103,
    backgroundColor: "transparent",
  },
  text: {
    left: 40,
  },
  lkr5850015: {
    left: 208,
  },
  payFrom: {
    width: 127,
    top: 131,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.plusJakartaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    left: 40,
    position: "absolute",
  },
  availableBalance: {
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    color: Color.colorWhite,
    position: "absolute",
    top: 167,
    width: 127,
    textAlign: "left",
    left: 208,
  },
  accountNumber: {
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    color: Color.colorWhite,
    position: "absolute",
    top: 167,
    width: 127,
    textAlign: "left",
    left: 40,
  },
  change: {
    left: 289,
    textDecoration: "underline",
    textAlign: "right",
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    color: Color.colorWhite,
    position: "absolute",
    top: 131,
  },
  moneyTransferPageInner: {
    top: 170,
    left: 182,
    borderColor: Color.colorGray_300,
    borderRightWidth: 1,
    width: 1,
    height: 33,
    borderStyle: "solid",
    position: "absolute",
  },
  rectangleView: {
    borderRadius: Border.br_5xs,
    borderWidth: 1,
    height: 100,
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
    width: 335,
    left: 20,
    top: 282,
    position: "absolute",
  },
  receiverInformation: {
    top: 242,
    color: Color.black,
    left: 20,
    position: "absolute",
  },
  arrowrightIcon: {
    height: "1.97%",
    width: "4.27%",
    top: "36.82%",
    right: "9.6%",
    bottom: "61.21%",
    left: "86.13%",
    borderRadius: 24,
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  combankNugegoda: {
    color: Color.blue,
    left: 15,
    top: 0,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.plusJakartaSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  frameChild: {
    left: 0,
  },
  combankNugegoda145Parent: {
    top: 302,
    left: 21,
    width: 333,
    height: 30,
    position: "absolute",
  },
  text1: {
    left: 0,
    top: 0,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.plusJakartaSansBold,
    fontWeight: "700",
    position: "absolute",
    color: Color.black,
  },
  frameItem: {
    display: "none",
    left: 15,
  },
  parent: {
    top: 352,
    left: 36,
    width: 110,
    height: 10,
    position: "absolute",
  },
  register: {
    color: Color.colorWhite,
    fontWeight: "600",
  },
  registerWrapper: {
    width: 274,
    justifyContent: "center",
  },
  mainBtn: {
    marginLeft: -167.5,
    top: 706,
    left: "50%",
    borderRadius: Border.br_31xl,
    backgroundColor: Color.blue,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    justifyContent: "center",
    alignItems: "center",
    width: 335,
    position: "absolute",
  },
  frameInner: {
    borderRadius: 4,
    width: 16,
    height: 16,
  },
  agreeTerms: {
    marginLeft: 8,
    color: Color.black,
    fontFamily: FontFamily.plusJakartaSansMedium,
    fontWeight: "500",
  },
  frameParent: {
    top: 572,
    width: 197,
    height: 16,
    left: 20,
    position: "absolute",
  },
  moneyTransferPage: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default MoneyTransferPage;
