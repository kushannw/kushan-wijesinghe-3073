import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { FontSize, Color, Border, FontFamily, Padding } from "../GlobalStyles";

const TransferSucessfull = () => {
  return (
    <View style={styles.transferSucessfull}>
      <View style={styles.rectangleParent}>
        <LinearGradient
          style={styles.frameChild}
          locations={[0, 1]}
          colors={["#1a52b5", "#3875e1"]}
        />
        <Text style={styles.paymentSuccess}>Payment Success!</Text>
        <Image
          style={styles.frameItem}
          contentFit="cover"
          source={require("../assets/group-26863.png")}
        />
        <Image
          style={styles.frameInner}
          contentFit="cover"
          source={require("../assets/group-26862.png")}
        />
        <View style={[styles.frameParent, styles.frameParentPosition]}>
          <View style={[styles.refIdWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.refId, styles.textTypo]}>Ref ID</Text>
          </View>
          <View style={[styles.wrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.text, styles.textTypo]}>56895236589</Text>
          </View>
        </View>
        <View style={[styles.frameGroup, styles.frameParentPosition]}>
          <View style={[styles.refIdWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.refId, styles.textTypo]}>Date</Text>
          </View>
          <View style={[styles.thOfMay2025Wrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.text, styles.textTypo]}>10th of May 2025</Text>
          </View>
        </View>
        <View style={[styles.frameContainer, styles.frameParentPosition]}>
          <View style={[styles.refIdWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.refId, styles.textTypo]}>Time</Text>
          </View>
          <View style={[styles.amWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.text, styles.textTypo]}>07:30 AM</Text>
          </View>
        </View>
        <View style={[styles.frameView, styles.frameParentPosition]}>
          <View style={[styles.refIdWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.refId, styles.textTypo]}>Payment Method</Text>
          </View>
          <View style={[styles.bankTransferWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.text, styles.textTypo]}>Bank Transfer</Text>
          </View>
        </View>
        <View style={[styles.frameParent1, styles.frameParentPosition]}>
          <View style={styles.amountWrapper}>
            <Text style={[styles.refId, styles.textTypo]}>Amount</Text>
          </View>
          <View style={[styles.bankTransferWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.lkr2500000, styles.textTypo]}>
              LKR 25,000.00
            </Text>
          </View>
        </View>
        <View style={[styles.lineView, styles.lineViewLayout]} />
        <View style={[styles.frameChild1, styles.lineViewLayout]} />
        <View style={[styles.mainBtn, styles.wrapperFlexBox]}>
          <View style={[styles.registerWrapper, styles.wrapperFlexBox]}>
            <Text style={[styles.text, styles.textTypo, register1Style]}>
              {register}
            </Text>
          </View>
        </View>
      </View>
      <Image
        style={[styles.transferSucessfullChild, styles.transferLayout]}
        contentFit="cover"
        source={require("../assets/frame-3.png")}
      />
      <Image
        style={[styles.transferSucessfullItem, styles.transferLayout]}
        contentFit="cover"
        source={require("../assets/group-26865.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameParentPosition: {
    left: 32,
    flexDirection: "row",
    position: "absolute",
  },
  wrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textTypo: {
    fontSize: FontSize.size_sm,
    color: Color.colorWhite,
  },
  lineViewLayout: {
    height: 1,
    width: 296,
    borderTopWidth: 1,
    borderColor: Color.colorGray_300,
    left: 32,
    position: "absolute",
  },
  transferLayout: {
    height: 40,
    width: 40,
    top: 68,
    position: "absolute",
  },
  frameChild: {
    top: 0,
    left: 12,
    borderRadius: Border.br_xs,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 16,
    elevation: 16,
    shadowOpacity: 1,
    borderColor: Color.colorDarkslategray_100,
    width: 335,
    backgroundColor: "transparent",
    borderWidth: 1,
    borderStyle: "solid",
    height: 566,
    position: "absolute",
  },
  paymentSuccess: {
    marginLeft: -108.5,
    top: 128,
    fontSize: FontSize.size_5xl,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    textAlign: "left",
    color: Color.colorWhite,
    left: "50%",
    position: "absolute",
  },
  frameItem: {
    top: 44,
    left: 153,
    width: 56,
    height: 56,
    position: "absolute",
  },
  frameInner: {
    top: 190,
    left: 0,
    height: 24,
    width: 359,
    position: "absolute",
  },
  refId: {
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    textAlign: "left",
  },
  refIdWrapper: {
    flexDirection: "row",
  },
  text: {
    fontWeight: "600",
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    textAlign: "left",
  },
  wrapper: {
    marginLeft: 161,
    flexDirection: "row",
  },
  frameParent: {
    top: 242,
    flexDirection: "row",
  },
  thOfMay2025Wrapper: {
    marginLeft: 153,
    flexDirection: "row",
  },
  frameGroup: {
    top: 276,
    flexDirection: "row",
  },
  amWrapper: {
    marginLeft: 197,
    flexDirection: "row",
  },
  frameContainer: {
    top: 310,
    flexDirection: "row",
  },
  bankTransferWrapper: {
    marginLeft: 90,
    flexDirection: "row",
  },
  frameView: {
    top: 344,
    flexDirection: "row",
  },
  amountWrapper: {
    width: 99,
    alignItems: "center",
    flexDirection: "row",
  },
  lkr2500000: {
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    textAlign: "right",
  },
  frameParent1: {
    top: 404,
    flexDirection: "row",
  },
  lineView: {
    top: 388,
    borderStyle: "dashed",
    borderRadius: 0.001,
  },
  frameChild1: {
    top: 450,
    borderStyle: "solid",
    height: 1,
    width: 296,
    borderTopWidth: 1,
    borderColor: Color.colorGray_300,
  },
  registerWrapper: {
    width: 274,
    flexDirection: "row",
  },
  mainBtn: {
    marginLeft: -147.5,
    top: 478,
    borderRadius: Border.br_31xl,
    borderColor: Color.colorWhite,
    width: 295,
    height: 44,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    left: "50%",
    justifyContent: "center",
    borderWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  rectangleParent: {
    top: 132,
    left: 8,
    height: 566,
    width: 359,
    position: "absolute",
  },
  transferSucessfullChild: {
    left: 20,
    borderRadius: Border.br_21xl,
  },
  transferSucessfullItem: {
    left: 315,
  },
  transferSucessfull: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default TransferSucessfull;
