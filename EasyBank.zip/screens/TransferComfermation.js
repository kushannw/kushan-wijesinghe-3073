import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Padding, Border } from "../GlobalStyles";

const TransferComfermation = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.transferComfermation, styles.iconLayout]}>
      <View style={styles.arrowbackwardParent}>
        <Pressable
          style={styles.arrowbackward}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={[styles.icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/arrowbackward.png")}
          />
        </Pressable>
        <View style={[styles.confirmationWrapper, styles.wrapperFlexBox]}>
          <Text style={styles.confirmation}>Confirmation</Text>
        </View>
      </View>
      <Pressable
        style={[styles.mainBtn, styles.mainBtnPosition]}
        onPress={() => navigation.navigate("TransferSucessfull")}
      >
        <View style={[styles.registerWrapper, styles.wrapperFlexBox]}>
          <Text style={[styles.register, styles.textTypo, register1Style]}>
            {register}
          </Text>
        </View>
      </Pressable>
      <View style={[styles.transferComfermationInner, styles.frameChildBorder]}>
        <View>
          <View>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>
                Sender Account Number
              </Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>285993209810</Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>
                Receiver Account Number
              </Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>5689423568974</Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>Transfer Amount</Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>LKR 25,000.00</Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>Receiver Reference</Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>
                Adobe Subscription Payment
              </Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>My Reference</Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>
                Adobe Subscription Payment
              </Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>Date</Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>
                10th of May 2025
              </Text>
            </View>
          </View>
          <View style={[styles.frameChild, styles.frameChildBorder]} />
          <View style={styles.frameContainer}>
            <View
              style={[styles.senderAccountNumberWrapper, styles.wrapperFlexBox]}
            >
              <Text style={styles.senderAccountNumber}>Ref ID</Text>
            </View>
            <View style={[styles.wrapper, styles.wrapperFlexBox]}>
              <Text style={[styles.text, styles.textTypo]}>56895236589</Text>
            </View>
          </View>
        </View>
      </View>
      <Image
        style={[styles.layer1Icon, styles.mainBtnPosition]}
        contentFit="cover"
        source={require("../assets/layer-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  wrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  mainBtnPosition: {
    left: "50%",
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  frameChildBorder: {
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  arrowbackward: {
    width: 28,
    height: 28,
  },
  confirmation: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    color: Color.blue,
    textAlign: "left",
    flex: 1,
  },
  confirmationWrapper: {
    marginLeft: 20,
    flexDirection: "row",
    flex: 1,
  },
  arrowbackwardParent: {
    top: 68,
    left: 20,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_12xs,
    alignItems: "center",
    position: "absolute",
    flexDirection: "row",
    width: 335,
  },
  register: {
    color: Color.colorWhite,
  },
  registerWrapper: {
    width: 274,
    flexDirection: "row",
  },
  mainBtn: {
    top: 706,
    borderRadius: Border.br_31xl,
    backgroundColor: Color.blue,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    marginLeft: -167.5,
    left: "50%",
    justifyContent: "center",
    alignItems: "center",
    width: 335,
  },
  senderAccountNumber: {
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorDarkgray,
    textAlign: "left",
  },
  senderAccountNumberWrapper: {
    flexDirection: "row",
  },
  text: {
    color: Color.black,
  },
  wrapper: {
    marginTop: 8,
    flexDirection: "row",
  },
  frameChild: {
    borderTopWidth: 1,
    width: 304,
    height: 1,
    marginTop: 12,
  },
  frameContainer: {
    marginTop: 12,
  },
  transferComfermationInner: {
    top: 122,
    borderRadius: Border.br_xs,
    borderWidth: 1,
    padding: 16,
    left: "50%",
    position: "absolute",
    marginLeft: -167.5,
    flexDirection: "row",
  },
  layer1Icon: {
    marginLeft: -36.5,
    top: 588,
    width: 72,
    height: 72,
    overflow: "hidden",
  },
  transferComfermation: {
    backgroundColor: Color.colorWhite,
    height: 812,
    overflow: "hidden",
    flex: 1,
  },
});

export default TransferComfermation;
