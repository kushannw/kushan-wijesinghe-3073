import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import RegisterForm from "../components/RegisterForm";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const Walkthourgh = () => {
  return (
    <View style={[styles.walkthourgh, styles.frameChildLayout]}>
      <View style={styles.frame}>
        <Image
          style={[styles.frameChild, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/group-1.png")}
        />
        <Text style={[styles.welcomeToEasy, styles.easyPosition]}>
          Welcome to Easy Bank
        </Text>
        <Text style={[styles.easyBank, styles.easyPosition]}>Easy Bank</Text>
        <Text
          style={styles.contraryToPopular}
        >{`Contrary to popular belief, Lorem Ipsum is not simply bank app `}</Text>
      </View>
      <RegisterForm />
    </View>
  );
};

const styles = StyleSheet.create({
  frameChildLayout: {
    width: "100%",
    overflow: "hidden",
  },
  easyPosition: {
    textAlign: "left",
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  frameChild: {
    height: "55.46%",
    top: "16.73%",
    right: "0%",
    bottom: "27.8%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  welcomeToEasy: {
    marginTop: 169,
    marginLeft: -132.85,
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    color: Color.black,
  },
  easyBank: {
    marginTop: -248,
    marginLeft: -78.85,
    fontSize: FontSize.size_13xl,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    color: Color.blue,
  },
  contraryToPopular: {
    top: 460,
    left: 18,
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorGray_100,
    textAlign: "center",
    width: 262,
    position: "absolute",
  },
  frame: {
    width: 300,
    height: 496,
    overflow: "hidden",
  },
  walkthourgh: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 812,
    alignItems: "center",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 70,
    overflow: "hidden",
  },
});

export default Walkthourgh;
