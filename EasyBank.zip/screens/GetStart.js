import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const GetStart = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.getStart}>
      <Text style={styles.hooray}>Hooray!</Text>
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <View style={[styles.frameItem, styles.frameLayout]} />
        <View style={[styles.frameInner, styles.frameLayout]} />
      </View>
      <Text style={[styles.yourAccountCreation, styles.step3OfPosition]}>
        Your account creation successful. So, Let’s Use our application
      </Text>
      <Button
        style={[styles.mainBtn, styles.mainBtnFlexBox]}
        title="Get Start"
        size="medium"
        status="primary"
        appearance="outline"
        color="#1a52b5"
        textStyle={styles.mainBtnText}
        onPress={() => navigation.navigate("Home")}
      >
        Get Start
      </Button>
      <Image
        style={styles.getStartChild}
        contentFit="cover"
        source={require("../assets/group-2.png")}
      />
      <Text style={[styles.step3Of, styles.step3OfTypo]}>Step 3 of 3</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout: {
    marginLeft: 11,
    backgroundColor: Color.blue,
    borderRadius: Border.br_7xs,
    height: 6,
  },
  step3OfPosition: {
    left: 24,
    position: "absolute",
  },
  mainBtnFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  step3OfTypo: {
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
  },
  hooray: {
    marginTop: -260,
    marginLeft: -163.5,
    top: "50%",
    fontSize: FontSize.size_13xl,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    color: Color.blue,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  frameChild: {
    width: 105,
    backgroundColor: Color.blue,
    borderRadius: Border.br_7xs,
    height: 6,
  },
  frameItem: {
    width: 103,
  },
  frameInner: {
    width: 105,
  },
  rectangleParent: {
    top: 94,
    alignItems: "center",
    height: 6,
    flexDirection: "row",
    width: 335,
    left: 24,
    position: "absolute",
  },
  yourAccountCreation: {
    top: 194,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorGray_100,
    width: 262,
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  mainBtn: {
    marginLeft: -167.5,
    top: 686,
    borderRadius: Border.br_31xl,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    justifyContent: "center",
    width: 335,
    left: "50%",
    position: "absolute",
  },
  getStartChild: {
    height: "35.09%",
    width: "86.93%",
    top: "38.92%",
    right: "6.4%",
    bottom: "26%",
    left: "6.67%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  step3Of: {
    top: 68,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 24,
    position: "absolute",
  },
  getStart: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default GetStart;
