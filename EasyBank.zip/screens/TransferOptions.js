import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import TransferOptionsContainer from "../components/TransferOptionsContainer";
import TransferOptionsContainer1 from "../components/TransferOptionsContainer1";
import DomesticPaymentContainer from "../components/DomesticPaymentContainer";
import { Border, Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const TransferOptions = () => {
  return (
    <View style={styles.transferOptions}>
      <TransferOptionsContainer transferOptionsText="Transfer Options" />
      <View style={styles.moneyTransferParent}>
        <TransferOptionsContainer1 />
        <DomesticPaymentContainer
          paymentDescription={require("../assets/domestic-payment.png")}
          paymentMethodCode="Domestic Payment"
        />
        <View style={[styles.billPayment, styles.billFlexBox]}>
          <View style={styles.vectorWrapper}>
            <Image
              style={styles.vectorIcon}
              contentFit="cover"
              source={require("../assets/vector.png")}
            />
          </View>
          <View style={[styles.billPaymentWrapper, styles.billFlexBox]}>
            <Text style={styles.billPayment1}>Bill Payment</Text>
          </View>
          <Image
            style={styles.arrowrightIcon}
            contentFit="cover"
            source={require("../assets/arrowright.png")}
          />
        </View>
        <DomesticPaymentContainer
          paymentDescription={require("../assets/credit-card-payment.png")}
          paymentMethodCode="Credit Card Payment"
          propWidth="55.58%"
          propLeft="23.26%"
        />
        <DomesticPaymentContainer
          paymentDescription={require("../assets/loan-payment.png")}
          paymentMethodCode="Loan Payment"
          propWidth="55.81%"
          propLeft="23.02%"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  billFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  vectorIcon: {
    position: "absolute",
    height: "55.81%",
    width: "41.63%",
    top: "20.93%",
    right: "28.37%",
    bottom: "23.26%",
    left: "30%",
    maxWidth: "100%",
    maxHeight: "100%",
    zIndex: 0,
    overflow: "hidden",
  },
  vectorWrapper: {
    borderRadius: Border.br_7xs,
    backgroundColor: Color.colorGhostwhite,
    flexDirection: "row",
  },
  billPayment1: {
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.black,
    textAlign: "left",
    width: 201,
  },
  billPaymentWrapper: {
    marginLeft: 20,
    flex: 1,
  },
  arrowrightIcon: {
    width: 24,
    height: 24,
    marginLeft: 20,
    overflow: "hidden",
  },
  billPayment: {
    borderRadius: Border.br_xs,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 16,
    elevation: 16,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderColor: Color.colorDarkslategray_100,
    borderWidth: 1,
    width: 335,
    padding: Padding.p_xs,
    marginTop: 12,
    backgroundColor: Color.colorWhite,
  },
  moneyTransferParent: {
    marginTop: -26,
  },
  transferOptions: {
    width: "100%",
    height: 812,
    justifyContent: "flex-end",
    paddingHorizontal: Padding.p_xl,
    paddingTop: 68,
    paddingBottom: 310,
    overflow: "hidden",
    flex: 1,
    backgroundColor: Color.colorWhite,
  },
});

export default TransferOptions;
