import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontFamily, Color } from "../GlobalStyles";

const Splash = () => {
  return (
    <View style={styles.splash}>
      <Text style={styles.easyBank}>Easy Bank</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  easyBank: {
    fontSize: 48,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    color: Color.blue,
    textAlign: "left",
  },
  splash: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Splash;
