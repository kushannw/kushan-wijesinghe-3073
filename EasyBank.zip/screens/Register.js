import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Button } from "@ui-kitten/components";
import TextFill from "../components/TextFill";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, FontSize, Color, Padding } from "../GlobalStyles";

const Register = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.register}>
      <TextFill
        formTitle="Enter Account Number"
        textFillPosition="absolute"
        textFillTop={278}
        textFillLeft={20}
        textFillWidth={335}
      />
      <TextFill
        formTitle="Enter NIC Number"
        textFillPosition="absolute"
        textFillTop={350}
        textFillLeft={20}
        textFillWidth={335}
      />
      <TextFill
        formTitle="Enter Mobile Number"
        textFillPosition="absolute"
        textFillTop={422}
        textFillLeft={20}
        textFillWidth={335}
      />
      <TextFill
        formTitle="Enter Password"
        textFillPosition="absolute"
        textFillTop={494}
        textFillLeft={20}
        textFillWidth={335}
      />
      <TextFill
        formTitle="Re-Enter Password"
        textFillPosition="absolute"
        textFillTop={566}
        textFillLeft={20}
        textFillWidth={335}
      />
      <Text style={styles.register1}>Register</Text>
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <View style={[styles.frameItem, styles.frameLayout]} />
        <View style={[styles.frameInner, styles.frameLayout]} />
      </View>
      <Text style={[styles.step1Of, styles.step1OfTypo]}>Step 1 of 3</Text>
      <Button
        style={[styles.mainBtn, styles.mainBtnFlexBox]}
        title="Register"
        size="medium"
        status="primary"
        appearance="filled"
        color="#1a52b5"
        textStyle={styles.mainBtnText}
        onPress={() => navigation.navigate("")}
      >
        Register
      </Button>
      <Button
        style={styles.haveAnAccount}
        title="Have an account? Sign In"
        size="medium"
        status="primary"
        appearance="outline"
      >
        Have an account? Sign In
      </Button>
      <Text
        style={[styles.contraryToPopular, styles.register2Typo]}
      >{`Contrary to popular belief, Lorem Ipsum is not simply bank app `}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout: {
    marginLeft: 11,
    borderRadius: Border.br_7xs,
    height: 6,
  },
  step1OfTypo: {
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
  },
  mainBtnFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  register2Typo: {
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  register1: {
    marginTop: -260,
    marginLeft: -163.5,
    top: "50%",
    fontSize: FontSize.size_13xl,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    color: Color.blue,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  frameChild: {
    backgroundColor: Color.blue,
    width: 105,
    borderRadius: Border.br_7xs,
    height: 6,
  },
  frameItem: {
    backgroundColor: "#d6d6d6",
    width: 103,
  },
  frameInner: {
    backgroundColor: Color.colorDarkslategray_200,
    width: 105,
  },
  rectangleParent: {
    top: 94,
    alignItems: "center",
    height: 6,
    flexDirection: "row",
    width: 335,
    left: 20,
    position: "absolute",
  },
  step1Of: {
    top: 68,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 20,
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  mainBtn: {
    marginLeft: -167.5,
    top: 650,
    borderRadius: Border.br_31xl,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    justifyContent: "center",
    width: 335,
    left: "50%",
    position: "absolute",
  },
  haveAnAccount: {
    marginLeft: -130.5,
    top: 730,
    left: "50%",
    position: "absolute",
  },
  contraryToPopular: {
    top: 194,
    left: 24,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorGray_100,
    width: 262,
    position: "absolute",
    fontSize: FontSize.size_base,
  },
  register: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Register;
