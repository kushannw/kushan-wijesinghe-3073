import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import CardForm from "../components/CardForm";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Home = () => {
  return (
    <View style={styles.home}>
      <CardForm
        transactionCode={require("../assets/arrowupright.png")}
        transactionDescription="Purchase Uber"
        transactionAmount="LKR 850"
      />
      <Text style={[styles.hiGoodMorning, styles.thisMonthTypo]}>
        Hi, Good Morning
      </Text>
      <Text style={[styles.davidMclearn, styles.davidMclearnPosition]}>
        David McLearn
      </Text>
      <Image
        style={[styles.homeChild, styles.homeChildLayout]}
        contentFit="cover"
        source={require("../assets/group-3.png")}
      />
      <View style={styles.debitCardParent}>
        <LinearGradient
          style={[styles.debitCard, styles.debitCardLayout]}
          locations={[0, 1]}
          colors={["#212226", "#3c3d40"]}
        >
          <Image
            style={[styles.debitCardChild, styles.debitChildPosition]}
            contentFit="cover"
            source={require("../assets/group-26838.png")}
          />
          <Image
            style={styles.frameIcon}
            contentFit="cover"
            source={require("../assets/frame.png")}
          />
          <View style={[styles.savingAccountParent, styles.parentFlexBox]}>
            <Text style={[styles.savingAccount, styles.expiryDateTypo]}>
              Saving Account
            </Text>
            <Text style={[styles.text, styles.textSpaceBlock]}>
              **** **** 9810
            </Text>
          </View>
          <View style={[styles.expiryDateParent, styles.parentFlexBox]}>
            <Text style={styles.expiryDateTypo}>Expiry Date</Text>
            <Text style={[styles.text, styles.textSpaceBlock]}>03/25</Text>
          </View>
          <View style={[styles.availableBalanceParent, styles.availableLayout]}>
            <Text style={styles.expiryDateTypo}>Available Balance</Text>
            <Text style={[styles.lkr47000000, styles.textSpaceBlock]}>
              LKR 470,000.00
            </Text>
          </View>
        </LinearGradient>
        <LinearGradient
          style={[styles.debitCard2, styles.debitCardLayout]}
          locations={[0, 1]}
          colors={["#4d70ff", "#243c9e"]}
        >
          <Image
            style={[styles.debitCard2Child, styles.debitChildPosition]}
            contentFit="cover"
            source={require("../assets/group-26838.png")}
          />
          <Image
            style={styles.frameIcon}
            contentFit="cover"
            source={require("../assets/frame.png")}
          />
          <View style={[styles.availableBalanceGroup, styles.availableLayout]}>
            <Text style={styles.expiryDateTypo}>Available Balance</Text>
            <Text style={[styles.lkr47000000, styles.textSpaceBlock]}>
              LKR 470,000.00
            </Text>
          </View>
          <View style={[styles.savingAccountGroup, styles.parentFlexBox]}>
            <Text style={[styles.savingAccount, styles.expiryDateTypo]}>
              Saving Account
            </Text>
            <Text style={[styles.text, styles.textSpaceBlock]}>
              **** **** 9810
            </Text>
          </View>
          <View style={[styles.expiryDateParent, styles.parentFlexBox]}>
            <Text style={styles.expiryDateTypo}>Expiry Date</Text>
            <Text style={[styles.text, styles.textSpaceBlock]}>03/25</Text>
          </View>
        </LinearGradient>
      </View>
      <Text style={[styles.recentTransactions, styles.davidMclearnPosition]}>
        Recent Transactions
      </Text>
      <CardForm
        transactionCode={require("../assets/arrowupright.png")}
        transactionDescription="Withdrawal Gampaha"
        transactionAmount="LKR 50,000"
        arrowuprightIconTop={380}
        lineViewLeft={225}
        lineViewWidth={110}
      />
      <CardForm
        transactionCode={require("../assets/arrowupright1.png")}
        transactionDescription="Salary - Fidenz"
        transactionAmount="LKR 94,804"
        arrowuprightIconTop={437}
        lineViewLeft={225}
        lineViewWidth={110}
      />
      <CardForm
        transactionCode={require("../assets/arrowupright1.png")}
        transactionDescription="Deposit Fast Cash"
        transactionAmount="LKR 1,000"
        arrowuprightIconTop={494}
        lineViewLeft={225}
        lineViewWidth={110}
      />
      <CardForm
        transactionCode={require("../assets/arrowupright.png")}
        transactionDescription="Purchase Daraz LK"
        transactionAmount="LKR 25,000"
        arrowuprightIconTop={551}
        lineViewLeft={226}
        lineViewWidth={109}
      />
      <CardForm
        transactionCode={require("../assets/arrowupright1.png")}
        transactionDescription="Project Payment"
        transactionAmount="LKR 8,200"
        arrowuprightIconTop={608}
        lineViewLeft={235}
        lineViewWidth={100}
      />
      <CardForm
        transactionCode={require("../assets/arrowupright.png")}
        transactionDescription="Purchase Uber Eats"
        transactionAmount="LKR 850"
        arrowuprightIconTop={665}
        lineViewLeft={250}
        lineViewWidth={85}
      />
      <View style={styles.thisMonthParent}>
        <Text style={[styles.thisMonth, styles.thisMonthTypo]}>This Month</Text>
        <Image
          style={styles.chevronforwardIcon}
          contentFit="cover"
          source={require("../assets/chevronforward.png")}
        />
      </View>
      <View style={styles.homeItem} />
    </View>
  );
};

const styles = StyleSheet.create({
  thisMonthTypo: {
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
  },
  davidMclearnPosition: {
    color: Color.blue,
    textAlign: "left",
    left: 20,
    position: "absolute",
  },
  homeChildLayout: {
    width: 40,
    left: 315,
  },
  debitCardLayout: {
    backgroundColor: "transparent",
    width: 327,
    borderWidth: 1,
    borderColor: Color.colorGray_200,
    borderStyle: "solid",
    borderRadius: Border.br_xs,
    top: 0,
    height: 180,
    position: "absolute",
  },
  debitChildPosition: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "80.73%",
    bottom: "73.33%",
    top: "13.33%",
    height: "13.33%",
    position: "absolute",
    overflow: "hidden",
  },
  parentFlexBox: {
    justifyContent: "flex-end",
    height: 26,
    position: "absolute",
  },
  expiryDateTypo: {
    color: Color.colorSilver,
    fontFamily: FontFamily.plusJakartaSansMedium,
    fontWeight: "500",
    fontSize: FontSize.size_5xs,
    textAlign: "left",
  },
  textSpaceBlock: {
    marginTop: 4,
    color: Color.colorWhite,
    textAlign: "left",
  },
  availableLayout: {
    height: 32,
    width: 202,
    left: 24,
    position: "absolute",
  },
  parentPosition: {
    height: 42,
    top: 47,
    alignItems: "center",
    position: "absolute",
  },
  home1Typo: {
    marginTop: 6,
    fontFamily: FontFamily.interMedium,
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    fontWeight: "500",
  },
  hiGoodMorning: {
    textAlign: "left",
    fontSize: FontSize.size_base,
    left: 20,
    color: Color.black,
    top: 68,
    position: "absolute",
  },
  davidMclearn: {
    top: 90,
    fontWeight: "800",
    fontFamily: FontFamily.plusJakartaSansExtraBold,
    fontSize: FontSize.size_5xl,
  },
  homeChild: {
    height: 40,
    top: 68,
    width: 40,
    left: 315,
    position: "absolute",
  },
  debitCardChild: {
    width: "11.9%",
    right: "7.37%",
  },
  frameIcon: {
    top: 24,
    width: 42,
    height: 28,
    left: 24,
    position: "absolute",
    overflow: "hidden",
  },
  savingAccount: {
    width: 127,
  },
  text: {
    fontFamily: FontFamily.jetBrainsMonoRegular,
    fontSize: FontSize.size_base,
  },
  savingAccountParent: {
    alignItems: "center",
    width: 135,
    height: 26,
    left: 24,
    top: 130,
  },
  expiryDateParent: {
    left: 255,
    width: 48,
    top: 130,
  },
  lkr47000000: {
    fontWeight: "700",
    fontFamily: FontFamily.jetBrainsMonoBold,
    fontSize: FontSize.size_5xl,
  },
  availableBalanceParent: {
    top: 75,
  },
  debitCard: {
    left: 0,
  },
  debitCard2Child: {
    width: "11.87%",
    right: "7.4%",
  },
  availableBalanceGroup: {
    top: 76,
  },
  savingAccountGroup: {
    top: 131,
    alignItems: "center",
    width: 135,
    height: 26,
    left: 24,
  },
  debitCard2: {
    left: 339,
  },
  debitCardParent: {
    top: 132,
    width: 335,
    height: 180,
    left: 20,
    position: "absolute",
  },
  recentTransactions: {
    top: 336,
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    color: Color.blue,
    fontSize: FontSize.size_base,
  },
  thisMonth: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  chevronforwardIcon: {
    width: 16,
    height: 15,
    marginLeft: 4,
    overflow: "hidden",
  },
  thisMonthParent: {
    top: 338,
    left: 273,
    flexDirection: "row",
    alignItems: "center",
    position: "absolute",
  },
  homeItem: {
    top: 714,
    left: 143,
    width: 98,
    height: 7,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  home: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default Home;
