import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const TransferOptionsContainer1 = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={[styles.moneyTransfer, styles.moneyFlexBox]}
      onPress={() => navigation.navigate("MoneyTransferPage")}
    >
      <View style={styles.moneyTransferWrapper}>
        <Image
          style={styles.moneyTransferIcon}
          contentFit="cover"
          source={require("../assets/money-transfer.png")}
        />
      </View>
      <View style={[styles.moneyTransferContainer, styles.moneyFlexBox]}>
        <Text style={styles.moneyTransfer1}>Money Transfer</Text>
      </View>
      <Image
        style={styles.arrowrightIcon}
        contentFit="cover"
        source={require("../assets/arrowright.png")}
      />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  moneyFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  moneyTransferIcon: {
    position: "absolute",
    height: "55.81%",
    width: "55.81%",
    top: "20.93%",
    right: "20.93%",
    bottom: "23.26%",
    left: "23.26%",
    maxWidth: "100%",
    maxHeight: "100%",
    zIndex: 0,
    overflow: "hidden",
  },
  moneyTransferWrapper: {
    borderRadius: Border.br_7xs,
    backgroundColor: Color.colorGhostwhite,
    flexDirection: "row",
  },
  moneyTransfer1: {
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.black,
    textAlign: "left",
    width: 201,
  },
  moneyTransferContainer: {
    flex: 1,
    marginLeft: 20,
  },
  arrowrightIcon: {
    width: 24,
    height: 24,
    marginLeft: 20,
    overflow: "hidden",
  },
  moneyTransfer: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.colorWhite,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 16,
    elevation: 16,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderColor: Color.colorDarkslategray_100,
    borderWidth: 1,
    width: 335,
    padding: Padding.p_xs,
  },
});

export default TransferOptionsContainer1;
