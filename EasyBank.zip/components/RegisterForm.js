import * as React from "react";
import { Button } from "@ui-kitten/components";
import { Text, StyleSheet, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const RegisterForm = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.frame}>
      <Button
        style={[styles.mainBtn, styles.mainBtnFlexBox1]}
        title="Register"
        size="medium"
        status="primary"
        appearance="filled"
        color="#1a52b5"
        textStyle={styles.mainBtnText}
        onPress={() => navigation.navigate("Register")}
      >
        Register
      </Button>
      <Button
        style={styles.signin}
        title="Sign In"
        size="medium"
        status="primary"
        appearance="filled"
        textStyle={styles.signinText}
      >
        Sign In
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  signinText: {
    fontWeight: "600",
    fontFamily: "PlusJakartaSans-SemiBold",
  },
  signInTypo: {
    textAlign: "left",
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
  },
  mainBtn: {
    borderRadius: Border.br_31xl,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
    width: 335,
  },
  signin: {
    width: 327,
    justifyContent: "center",
    marginTop: 24,
    flexDirection: "row",
    alignItems: "center",
  },
  frame: {
    height: 92,
    overflow: "hidden",
    marginTop: 36,
    alignItems: "center",
    width: 335,
  },
});

export default RegisterForm;
