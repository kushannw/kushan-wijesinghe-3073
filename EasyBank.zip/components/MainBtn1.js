import * as React from "react";
import { Button } from "@ui-kitten/components";
import { Text, StyleSheet, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Padding } from "../GlobalStyles";

const MainBtn11 = () => {
  const navigation = useNavigation();

  return (
    <Button
      style={[styles.mainBtn, styles.mainBtnFlexBox1]}
      title="Register"
      size="medium"
      status="primary"
      appearance="filled"
      color="#1a52b5"
      textStyle={styles.mainBtnText}
      onPress={() => navigation.navigate("Register")}
    >
      Register
    </Button>
  );
};

const styles = StyleSheet.create({
  mainBtnText: {
    fontWeight: "600",
    fontFamily: "PlusJakartaSans-SemiBold",
  },
  mainBtnFlexBox1: {
    justifyContent: "center",
    alignItems: "center",
  },
  mainBtn: {
    borderRadius: Border.br_31xl,
    width: 335,
    height: 56,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_3xl,
  },
});

export default MainBtn11;
