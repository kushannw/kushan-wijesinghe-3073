import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const TextFill = ({
  formTitle,
  textFillPosition,
  textFillTop,
  textFillLeft,
  textFillWidth,
}) => {
  const textFillStyle = useMemo(() => {
    return {
      ...getStyleValue("position", textFillPosition),
      ...getStyleValue("top", textFillTop),
      ...getStyleValue("left", textFillLeft),
      ...getStyleValue("width", textFillWidth),
    };
  }, [textFillPosition, textFillTop, textFillLeft, textFillWidth]);

  return (
    <View style={[styles.textFill, textFillStyle]}>
      <View style={styles.registerWrapper}>
        <Text style={styles.register}>{formTitle}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  register: {
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorDarkgray,
    textAlign: "left",
  },
  registerWrapper: {
    width: 287,
    flexDirection: "row",
    alignItems: "center",
  },
  textFill: {
    borderRadius: Border.br_31xl,
    borderStyle: "solid",
    borderColor: Color.colorDarkslategray_200,
    borderWidth: 1,
    width: 335,
    justifyContent: "center",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_4xl,
    alignItems: "center",
  },
});

export default TextFill;
