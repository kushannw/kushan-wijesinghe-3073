import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const TransferOptionsContainer = ({
  transferOptionsText,
  frameViewPosition,
  frameViewTop,
  frameViewLeft,
}) => {
  const frameViewStyle = useMemo(() => {
    return {
      ...getStyleValue("position", frameViewPosition),
      ...getStyleValue("top", frameViewTop),
      ...getStyleValue("left", frameViewLeft),
    };
  }, [frameViewPosition, frameViewTop, frameViewLeft]);

  return (
    <View style={[styles.frameParent, frameViewStyle]}>
      <View style={styles.transferOptionsWrapper}>
        <Text style={styles.transferOptions}>{transferOptionsText}</Text>
      </View>
      <Image
        style={styles.frameChild}
        contentFit="cover"
        source={require("../assets/frame-3.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  transferOptions: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    color: Color.blue,
    textAlign: "left",
    width: 296,
  },
  transferOptionsWrapper: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  frameChild: {
    borderRadius: Border.br_21xl,
    width: 40,
    height: 40,
    marginTop: 10,
  },
  frameParent: {
    width: 335,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_12xs,
  },
});

export default TransferOptionsContainer;
