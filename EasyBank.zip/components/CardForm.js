import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const CardForm = ({
  transactionCode,
  transactionDescription,
  transactionAmount,
  arrowuprightIconTop,
  lineViewLeft,
  lineViewWidth,
}) => {
  const frameView1Style = useMemo(() => {
    return {
      ...getStyleValue("top", arrowuprightIconTop),
    };
  }, [arrowuprightIconTop]);

  const lKR850Style = useMemo(() => {
    return {
      ...getStyleValue("left", lineViewLeft),
      ...getStyleValue("width", lineViewWidth),
    };
  }, [lineViewLeft, lineViewWidth]);

  return (
    <View style={[styles.arrowuprightParent, frameView1Style]}>
      <Image
        style={styles.arrowuprightIcon}
        contentFit="cover"
        source={transactionCode}
      />
      <View style={styles.purchaseUberParent}>
        <Text style={[styles.purchaseUber, styles.lkr850Clr]}>
          {transactionDescription}
        </Text>
        <Text style={styles.sep2022}>09 Sep 2022 - 10:15 am</Text>
      </View>
      <Text style={[styles.lkr850, styles.lkr850Clr, lKR850Style]}>
        {transactionAmount}
      </Text>
      <View style={styles.frameChild} />
    </View>
  );
};

const styles = StyleSheet.create({
  lkr850Clr: {
    color: Color.black,
    fontSize: FontSize.size_sm,
  },
  arrowuprightIcon: {
    height: "44.44%",
    width: "6.03%",
    top: "13.33%",
    right: "93.97%",
    bottom: "42.22%",
    left: "0%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  purchaseUber: {
    fontWeight: "600",
    fontFamily: FontFamily.plusJakartaSansSemiBold,
    textAlign: "left",
    width: 147,
  },
  sep2022: {
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
    fontFamily: FontFamily.plusJakartaSansMedium,
    color: Color.colorGray_100,
    width: 127,
    marginTop: 2,
    textAlign: "left",
  },
  purchaseUberParent: {
    top: 0,
    left: 32,
    height: 33,
    paddingHorizontal: 0,
    paddingVertical: 0,
    width: 147,
    position: "absolute",
  },
  lkr850: {
    top: 7,
    left: 250,
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    textAlign: "right",
    width: 85,
    position: "absolute",
  },
  frameChild: {
    top: 45,
    left: 0,
    borderStyle: "solid",
    borderColor: Color.colorDarkslategray_100,
    borderTopWidth: 1,
    width: 336,
    height: 1,
    position: "absolute",
  },
  arrowuprightParent: {
    top: 724,
    left: 20,
    width: 335,
    height: 45,
    position: "absolute",
  },
});

export default CardForm;
