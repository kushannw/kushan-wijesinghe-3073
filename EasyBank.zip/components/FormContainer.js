import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const FormContainer = () => {
  return (
    <View style={styles.frameParent}>
      <View style={[styles.lkr2500000Parent, styles.parentLayout]}>
        <Text style={styles.lkr2500000}>LKR 25,000.00</Text>
        <View style={[styles.frameChild, styles.frameLayout]} />
      </View>
      <View style={[styles.receiverReferenceParent, styles.parentLayout]}>
        <Text style={[styles.receiverReference, styles.referenceTypo]}>
          Receiver Reference
        </Text>
        <View style={[styles.frameChild, styles.frameLayout]} />
      </View>
      <View style={styles.myReferenceParent}>
        <Text style={[styles.myReference, styles.referenceTypo]}>
          My Reference
        </Text>
        <View style={[styles.frameInner, styles.frameLayout]} />
      </View>
      <Image
        style={[
          styles.exclamationmarkcircleIcon,
          styles.exclamationmarkcircleIconLayout,
        ]}
        contentFit="cover"
        source={require("../assets/exclamationmarkcircle.png")}
      />
      <Image
        style={[
          styles.exclamationmarkcircleIcon1,
          styles.exclamationmarkcircleIconLayout,
        ]}
        contentFit="cover"
        source={require("../assets/exclamationmarkcircle.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  parentLayout: {
    height: 30,
    width: 333,
    left: 1,
    position: "absolute",
  },
  frameLayout: {
    height: 1,
    width: 334,
    borderTopWidth: 1,
    top: 30,
    borderStyle: "solid",
    position: "absolute",
  },
  referenceTypo: {
    color: Color.colorDarkgray,
    fontFamily: FontFamily.plusJakartaSansMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_sm,
    top: 0,
    position: "absolute",
  },
  exclamationmarkcircleIconLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    left: "89.25%",
    right: "4.78%",
    width: "5.97%",
    height: "13.33%",
    position: "absolute",
  },
  lkr2500000: {
    fontWeight: "700",
    fontFamily: FontFamily.plusJakartaSansBold,
    color: Color.black,
    textAlign: "left",
    fontSize: FontSize.size_sm,
    top: 0,
    left: 15,
    position: "absolute",
  },
  frameChild: {
    left: 0,
    borderColor: Color.colorDarkslategray_100,
  },
  lkr2500000Parent: {
    top: 20,
  },
  receiverReference: {
    left: 15,
  },
  receiverReferenceParent: {
    top: 70,
  },
  myReference: {
    left: 0,
  },
  frameInner: {
    borderColor: Color.colorDarkgray,
    display: "none",
    left: 15,
  },
  myReferenceParent: {
    top: 120,
    left: 16,
    width: 92,
    height: 10,
    position: "absolute",
  },
  exclamationmarkcircleIcon: {
    top: "43.33%",
    bottom: "43.33%",
  },
  exclamationmarkcircleIcon1: {
    top: "76.67%",
    bottom: "10%",
  },
  frameParent: {
    top: 402,
    left: 20,
    borderRadius: Border.br_5xs,
    borderWidth: 1,
    width: 335,
    height: 150,
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
    position: "absolute",
  },
});

export default FormContainer;
